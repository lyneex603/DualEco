# DualEco

Две валюты: **монеты** (через Vault — работают в любых магазинах/аренах/квестах) и **донат-валюта** (Рубины).
Bedrock: ник с префиксом Floodgate, форма кошелька (/wallet).

## Сборка
    mvn clean package
Готовый файл: target/DualEco.jar -> в папку plugins/. Нужны: Vault. Опционально: PlaceholderAPI, Floodgate.

## Команды
/balance [игрок], /pay <игрок> <сумма>, /wallet, /baltop
/dualeco coins|donate give|take|set <игрок> <сумма> [id_платежа]
/dualeco balance <игрок>, /dualeco reload

## EasyDonate
Команда для товара (выдача донат-валюты):
    dualeco donate give {user} 100 {purchase_id}
Монеты:
    dualeco coins give {user} 5000
Плейсхолдеры (названия подставляет EasyDonate: {user} / {purchase_id} — сверьтесь с их документацией).
Повторный id платежа игнорируется — двойного начисления не будет.

## PlaceholderAPI
%dualeco_coins%, %dualeco_coins_raw%, %dualeco_donate%, %dualeco_donate_name%

## Покупка за донат-валюту (DeluxeMenus и т.п.)
requirement: %dualeco_donate% >= 100
команда: [console] dualeco donate take %player_name% 100
