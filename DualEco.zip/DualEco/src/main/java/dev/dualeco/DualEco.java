package dev.dualeco;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class DualEco extends JavaPlugin implements Listener {
    private static DualEco instance;
    private EcoManager manager;
    private boolean floodgate;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        manager = new EcoManager(this);
        try {
            manager.init();
        } catch (Exception e) {
            getLogger().severe("Не удалось открыть базу данных: " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        floodgate = getServer().getPluginManager().getPlugin("floodgate") != null;

        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            getServer().getServicesManager().register(Economy.class,
                    new VaultProvider(this, manager), this, ServicePriority.Highest);
            getLogger().info("Vault: экономика (монеты) зарегистрирована.");
        } else {
            getLogger().warning("Vault не найден — другие плагины не увидят монеты.");
        }

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new Placeholders(this, manager).register();
            getLogger().info("PlaceholderAPI: %dualeco_coins%, %dualeco_donate% и др.");
        }

        Commands cmd = new Commands(this, manager);
        for (String name : new String[]{"balance", "pay", "wallet", "baltop", "dualeco"}) {
            getCommand(name).setExecutor(cmd);
            getCommand(name).setTabCompleter(cmd);
        }
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.close();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        manager.get(p.getUniqueId(), p.getName());
    }

    public static DualEco getInstance() { return instance; }
    public EcoManager getManager() { return manager; }
    public boolean hasFloodgate() { return floodgate; }

    /** Сообщение из config.yml с заменой плейсхолдеров: msg("key", "%a%", "1", "%b%", "2"). */
    public String msg(String key, String... repl) {
        String s = getConfig().getString("messages." + key, key);
        return format(s, repl);
    }

    public String format(String s, String... repl) {
        s = s.replace("%donate_name%", getConfig().getString("donate.name", "Рубины"));
        for (int i = 0; i + 1 < repl.length; i += 2) s = s.replace(repl[i], repl[i + 1]);
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public String fmtCoins(double v) {
        DecimalFormatSymbols sym = DecimalFormatSymbols.getInstance(Locale.US);
        sym.setGroupingSeparator(' ');
        return new DecimalFormat("#,##0.##", sym).format(v);
    }
}
