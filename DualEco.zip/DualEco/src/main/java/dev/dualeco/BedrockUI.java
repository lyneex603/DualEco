package dev.dualeco;

import dev.dualeco.EcoManager.Account;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.UUID;

/** Формы для Bedrock-игроков. Загружается только если на сервере есть Floodgate. */
public final class BedrockUI {
    private BedrockUI() {}

    public static boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    public static void wallet(DualEco pl, Player p, Account a) {
        String content = pl.format(pl.getConfig().getString("form.content", ""),
                "%coins%", pl.fmtCoins(a.coins), "%donate%", String.valueOf(a.donate));
        SimpleForm form = SimpleForm.builder()
                .title(pl.getConfig().getString("form.title", "Кошелёк"))
                .content(content)
                .button(pl.getConfig().getString("form.button-top", "Топ"))
                .button(pl.getConfig().getString("form.button-close", "Закрыть"))
                .validResultHandler(r -> {
                    if (r.clickedButtonId() == 0) {
                        Bukkit.getScheduler().runTask(pl, () -> p.performCommand("baltop"));
                    }
                })
                .build();
        FloodgateApi.getInstance().sendForm(p.getUniqueId(), form);
    }
}
