package dev.dualeco;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Хранилище балансов (SQLite). Кэш в памяти, запись в БД асинхронно.
 * Публичный API для других плагинов: DualEco.getInstance().getManager()
 */
public class EcoManager {

    public static class Account {
        public final UUID uuid;
        public volatile String name;
        public volatile double coins;
        public volatile long donate;

        Account(UUID uuid, String name, double coins, long donate) {
            this.uuid = uuid; this.name = name; this.coins = coins; this.donate = donate;
        }
    }

    public record TopEntry(String name, double coins) {}

    private final DualEco plugin;
    private final Map<UUID, Account> cache = new ConcurrentHashMap<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "DualEco-IO"));
    private Connection conn;

    public EcoManager(DualEco plugin) { this.plugin = plugin; }

    public void init() throws Exception {
        plugin.getDataFolder().mkdirs();
        Class.forName("org.sqlite.JDBC");
        File f = new File(plugin.getDataFolder(), "data.db");
        conn = DriverManager.getConnection("jdbc:sqlite:" + f.getAbsolutePath());
        try (Statement st = conn.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS balances (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, "
                    + "coins REAL NOT NULL DEFAULT 0, donate INTEGER NOT NULL DEFAULT 0)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS payments (id TEXT PRIMARY KEY, uuid TEXT NOT NULL, "
                    + "amount INTEGER NOT NULL, ts INTEGER NOT NULL)");
            st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_name ON balances(name COLLATE NOCASE)");
        }
    }

    public void close() {
        io.shutdown();
        try { io.awaitTermination(15, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
    }

    // ---------- аккаунты ----------

    /** Получить (или создать) аккаунт по UUID. nameHint может быть null. */
    public synchronized Account get(UUID id, String nameHint) {
        Account a = cache.get(id);
        if (a != null) {
            if (nameHint != null && !nameHint.equals(a.name)) { a.name = nameHint; save(a); }
            return a;
        }
        try (PreparedStatement ps = conn.prepareStatement("SELECT name, coins, donate FROM balances WHERE uuid=?")) {
            ps.setString(1, id.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    a = new Account(id, nameHint != null ? nameHint : rs.getString(1), rs.getDouble(2), rs.getLong(3));
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
        if (a == null) {
            double start = plugin.getConfig().getDouble("start-balance", 0);
            a = new Account(id, nameHint != null ? nameHint : id.toString(), start, 0);
            save(a);
        }
        cache.put(id, a);
        return a;
    }

    /** Поиск по нику (без учёта регистра). Если не найден — пробует с префиксом Bedrock. */
    public synchronized Account findByName(String name) {
        Account a = findExact(name);
        if (a == null) {
            String prefix = plugin.getConfig().getString("bedrock-prefix", ".");
            if (!prefix.isEmpty() && !name.startsWith(prefix)) a = findExact(prefix + name);
        }
        return a;
    }

    private Account findExact(String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p != null) return get(p.getUniqueId(), p.getName());
        for (Account c : cache.values()) if (c.name.equalsIgnoreCase(name)) return c;
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT uuid FROM balances WHERE name = ? COLLATE NOCASE LIMIT 1")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return get(UUID.fromString(rs.getString(1)), null);
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
        return null;
    }

    // ---------- операции ----------

    public static double round(double v) { return Math.round(v * 100.0) / 100.0; }

    public synchronized boolean addCoins(Account a, double delta) {
        double n = round(a.coins + delta);
        if (n < 0) return false;
        a.coins = n; save(a);
        return true;
    }

    public synchronized void setCoins(Account a, double v) { a.coins = Math.max(0, round(v)); save(a); }

    public synchronized boolean addDonate(Account a, long delta) {
        long n = a.donate + delta;
        if (n < 0) return false;
        a.donate = n; save(a);
        return true;
    }

    public synchronized void setDonate(Account a, long v) { a.donate = Math.max(0, v); save(a); }

    public synchronized boolean transfer(Account from, Account to, double amount) {
        if (from.coins < amount) return false;
        from.coins = round(from.coins - amount);
        to.coins = round(to.coins + amount);
        save(from); save(to);
        return true;
    }

    /** Защита от двойного начисления: true, если платёж с таким id ещё не обрабатывался. */
    public synchronized boolean registerPayment(String id, UUID uuid, long amount) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO payments(id, uuid, amount, ts) VALUES(?,?,?,?)")) {
            ps.setString(1, id);
            ps.setString(2, uuid.toString());
            ps.setLong(3, amount);
            ps.setLong(4, System.currentTimeMillis() / 1000);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }

    public synchronized List<TopEntry> top(int limit) {
        List<TopEntry> list = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT name, coins FROM balances ORDER BY coins DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new TopEntry(rs.getString(1), rs.getDouble(2)));
            }
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
        return list;
    }

    // ---------- запись ----------

    private void save(Account a) {
        final String uuid = a.uuid.toString(), name = a.name;
        final double coins = a.coins;
        final long donate = a.donate;
        io.execute(() -> {
            synchronized (EcoManager.this) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO balances(uuid, name, coins, donate) VALUES(?,?,?,?) "
                                + "ON CONFLICT(uuid) DO UPDATE SET name=excluded.name, "
                                + "coins=excluded.coins, donate=excluded.donate")) {
                    ps.setString(1, uuid);
                    ps.setString(2, name);
                    ps.setDouble(3, coins);
                    ps.setLong(4, donate);
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().severe("Ошибка сохранения " + name + ": " + e);
                }
            }
        });
    }
}
