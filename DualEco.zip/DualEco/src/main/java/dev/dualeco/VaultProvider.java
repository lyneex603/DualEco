package dev.dualeco;

import dev.dualeco.EcoManager.Account;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.OfflinePlayer;

import java.util.Collections;
import java.util.List;

/** Vault-провайдер: Vault работает ТОЛЬКО с монетами. Донат-валюта — отдельно. */
public class VaultProvider implements Economy {
    private final DualEco pl;
    private final EcoManager m;

    public VaultProvider(DualEco pl, EcoManager m) { this.pl = pl; this.m = m; }

    private Account acc(OfflinePlayer p) { return m.get(p.getUniqueId(), p.getName()); }
    private Account acc(String name) { return m.findByName(name); }

    private double bal(Account a) { return a == null ? 0 : a.coins; }

    private EconomyResponse dep(Account a, double amt) {
        if (a == null) return new EconomyResponse(0, 0, ResponseType.FAILURE, "Аккаунт не найден");
        if (amt < 0) return new EconomyResponse(0, a.coins, ResponseType.FAILURE, "Отрицательная сумма");
        m.addCoins(a, amt);
        return new EconomyResponse(amt, a.coins, ResponseType.SUCCESS, null);
    }

    private EconomyResponse wd(Account a, double amt) {
        if (a == null) return new EconomyResponse(0, 0, ResponseType.FAILURE, "Аккаунт не найден");
        if (amt < 0) return new EconomyResponse(0, a.coins, ResponseType.FAILURE, "Отрицательная сумма");
        if (!m.addCoins(a, -amt)) return new EconomyResponse(0, a.coins, ResponseType.FAILURE, "Недостаточно средств");
        return new EconomyResponse(amt, a.coins, ResponseType.SUCCESS, null);
    }

    private EconomyResponse noBank() {
        return new EconomyResponse(0, 0, ResponseType.NOT_IMPLEMENTED, "Банки не поддерживаются");
    }

    @Override public boolean isEnabled() { return pl.isEnabled(); }
    @Override public String getName() { return "DualEco"; }
    @Override public boolean hasBankSupport() { return false; }
    @Override public int fractionalDigits() { return 2; }
    @Override public String format(double amount) {
        return pl.fmtCoins(amount) + " " + (amount == 1
                ? pl.getConfig().getString("coins.name-singular", "монета")
                : pl.getConfig().getString("coins.name-plural", "монет"));
    }
    @Override public String currencyNamePlural() { return pl.getConfig().getString("coins.name-plural", "монет"); }
    @Override public String currencyNameSingular() { return pl.getConfig().getString("coins.name-singular", "монета"); }

    @Override public boolean hasAccount(String n) { return acc(n) != null; }
    @Override public boolean hasAccount(OfflinePlayer p) { return true; }
    @Override public boolean hasAccount(String n, String w) { return hasAccount(n); }
    @Override public boolean hasAccount(OfflinePlayer p, String w) { return true; }

    @Override public double getBalance(String n) { return bal(acc(n)); }
    @Override public double getBalance(OfflinePlayer p) { return bal(acc(p)); }
    @Override public double getBalance(String n, String w) { return getBalance(n); }
    @Override public double getBalance(OfflinePlayer p, String w) { return getBalance(p); }

    @Override public boolean has(String n, double a) { return getBalance(n) >= a; }
    @Override public boolean has(OfflinePlayer p, double a) { return getBalance(p) >= a; }
    @Override public boolean has(String n, String w, double a) { return has(n, a); }
    @Override public boolean has(OfflinePlayer p, String w, double a) { return has(p, a); }

    @Override public EconomyResponse withdrawPlayer(String n, double a) { return wd(acc(n), a); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer p, double a) { return wd(acc(p), a); }
    @Override public EconomyResponse withdrawPlayer(String n, String w, double a) { return withdrawPlayer(n, a); }
    @Override public EconomyResponse withdrawPlayer(OfflinePlayer p, String w, double a) { return withdrawPlayer(p, a); }

    @Override public EconomyResponse depositPlayer(String n, double a) { return dep(acc(n), a); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer p, double a) { return dep(acc(p), a); }
    @Override public EconomyResponse depositPlayer(String n, String w, double a) { return depositPlayer(n, a); }
    @Override public EconomyResponse depositPlayer(OfflinePlayer p, String w, double a) { return depositPlayer(p, a); }

    @Override public EconomyResponse createBank(String name, String player) { return noBank(); }
    @Override public EconomyResponse createBank(String name, OfflinePlayer player) { return noBank(); }
    @Override public EconomyResponse deleteBank(String name) { return noBank(); }
    @Override public EconomyResponse bankBalance(String name) { return noBank(); }
    @Override public EconomyResponse bankHas(String name, double amount) { return noBank(); }
    @Override public EconomyResponse bankWithdraw(String name, double amount) { return noBank(); }
    @Override public EconomyResponse bankDeposit(String name, double amount) { return noBank(); }
    @Override public EconomyResponse isBankOwner(String name, String player) { return noBank(); }
    @Override public EconomyResponse isBankOwner(String name, OfflinePlayer player) { return noBank(); }
    @Override public EconomyResponse isBankMember(String name, String player) { return noBank(); }
    @Override public EconomyResponse isBankMember(String name, OfflinePlayer player) { return noBank(); }
    @Override public List<String> getBanks() { return Collections.emptyList(); }

    @Override public boolean createPlayerAccount(String n) { return acc(n) != null; }
    @Override public boolean createPlayerAccount(OfflinePlayer p) { acc(p); return true; }
    @Override public boolean createPlayerAccount(String n, String w) { return createPlayerAccount(n); }
    @Override public boolean createPlayerAccount(OfflinePlayer p, String w) { return createPlayerAccount(p); }
}
