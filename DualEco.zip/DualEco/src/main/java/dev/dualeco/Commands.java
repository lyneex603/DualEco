package dev.dualeco;

import dev.dualeco.EcoManager.Account;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public class Commands implements CommandExecutor, TabCompleter {
    private final DualEco pl;
    private final EcoManager m;

    public Commands(DualEco pl, EcoManager m) { this.pl = pl; this.m = m; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        switch (c.getName().toLowerCase()) {
            case "balance" -> balance(s, a);
            case "pay" -> pay(s, a);
            case "wallet" -> wallet(s);
            case "baltop" -> baltop(s);
            case "dualeco" -> admin(s, a);
        }
        return true;
    }

    // ---------- игрокам ----------

    private void balance(CommandSender s, String[] a) {
        if (a.length > 0 && s.hasPermission("dualeco.balance.others")) {
            Account t = m.findByName(a[0]);
            if (t == null) { s.sendMessage(pl.msg("player-not-found", "%player%", a[0])); return; }
            s.sendMessage(pl.msg("balance-other", "%player%", t.name,
                    "%coins%", pl.fmtCoins(t.coins), "%donate%", String.valueOf(t.donate)));
        } else if (s instanceof Player p) {
            Account t = m.get(p.getUniqueId(), p.getName());
            s.sendMessage(pl.msg("balance-self", "%coins%", pl.fmtCoins(t.coins), "%donate%", String.valueOf(t.donate)));
        } else {
            s.sendMessage(pl.msg("only-player"));
        }
    }

    private void wallet(CommandSender s) {
        if (!(s instanceof Player p)) { s.sendMessage(pl.msg("only-player")); return; }
        Account a = m.get(p.getUniqueId(), p.getName());
        if (pl.hasFloodgate() && BedrockUI.isBedrock(p.getUniqueId())) {
            BedrockUI.wallet(pl, p, a);
        } else {
            balance(s, new String[0]);
        }
    }

    private void pay(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage(pl.msg("only-player")); return; }
        if (!p.hasPermission("dualeco.pay")) { s.sendMessage(pl.msg("no-perm")); return; }
        if (a.length < 2) { s.sendMessage(pl.msg("pay-usage")); return; }
        Account to = m.findByName(a[0]);
        if (to == null) { s.sendMessage(pl.msg("player-not-found", "%player%", a[0])); return; }
        if (to.uuid.equals(p.getUniqueId())) { s.sendMessage(pl.msg("pay-self")); return; }
        double amt = parse(a[1]);
        if (Double.isNaN(amt) || amt <= 0) { s.sendMessage(pl.msg("invalid-number")); return; }
        double min = pl.getConfig().getDouble("coins.min-pay", 1.0);
        if (amt < min) { s.sendMessage(pl.msg("pay-min", "%min%", pl.fmtCoins(min))); return; }
        Account from = m.get(p.getUniqueId(), p.getName());
        if (!m.transfer(from, to, amt)) { s.sendMessage(pl.msg("pay-no-money")); return; }
        s.sendMessage(pl.msg("pay-sent", "%amount%", pl.fmtCoins(amt), "%player%", to.name));
        Player online = Bukkit.getPlayer(to.uuid);
        if (online != null) online.sendMessage(pl.msg("pay-received", "%amount%", pl.fmtCoins(amt), "%player%", p.getName()));
    }

    private void baltop(CommandSender s) {
        s.sendMessage(pl.msg("baltop-header"));
        int i = 1;
        for (EcoManager.TopEntry e : m.top(10)) {
            s.sendMessage(pl.msg("baltop-line", "%pos%", String.valueOf(i++),
                    "%player%", e.name(), "%coins%", pl.fmtCoins(e.coins())));
        }
    }

    // ---------- админ / EasyDonate ----------

    private void admin(CommandSender s, String[] a) {
        if (!s.hasPermission("dualeco.admin")) { s.sendMessage(pl.msg("no-perm")); return; }
        if (a.length == 0) { s.sendMessage(pl.msg("usage-admin")); return; }
        String sub = a[0].toLowerCase();

        if (sub.equals("reload")) {
            pl.reloadConfig();
            s.sendMessage(pl.msg("reloaded"));
            return;
        }
        if (sub.equals("balance") && a.length >= 2) {
            Account t = m.findByName(a[1]);
            if (t == null) { s.sendMessage(pl.msg("player-not-found", "%player%", a[1])); return; }
            s.sendMessage(pl.msg("balance-other", "%player%", t.name,
                    "%coins%", pl.fmtCoins(t.coins), "%donate%", String.valueOf(t.donate)));
            return;
        }
        if ((sub.equals("coins") || sub.equals("donate")) && a.length >= 4) {
            boolean donate = sub.equals("donate");
            String op = a[1].toLowerCase();
            if (!op.equals("give") && !op.equals("take") && !op.equals("set")) {
                s.sendMessage(pl.msg("usage-admin")); return;
            }
            Account t = m.findByName(a[2]);
            if (t == null) { s.sendMessage(pl.msg("player-not-found", "%player%", a[2])); return; }
            double amt = parse(a[3]);
            if (Double.isNaN(amt) || (donate && amt != Math.rint(amt))) {
                s.sendMessage(pl.msg("invalid-number")); return;
            }
            String payId = a.length > 4 ? a[4] : null;
            if (donate && op.equals("give") && payId != null && !m.registerPayment(payId, t.uuid, (long) amt)) {
                s.sendMessage(pl.msg("duplicate-payment", "%id%", payId));
                return;
            }

            boolean ok = true;
            if (donate) {
                long v = (long) amt;
                switch (op) {
                    case "give" -> m.addDonate(t, v);
                    case "take" -> ok = m.addDonate(t, -v);
                    default -> m.setDonate(t, v);
                }
            } else {
                switch (op) {
                    case "give" -> m.addCoins(t, amt);
                    case "take" -> ok = m.addCoins(t, -amt);
                    default -> m.setCoins(t, amt);
                }
            }
            if (!ok) { s.sendMessage(pl.msg("admin-not-enough")); return; }

            s.sendMessage(pl.msg("admin-done", "%player%", t.name,
                    "%coins%", pl.fmtCoins(t.coins), "%donate%", String.valueOf(t.donate)));
            pl.getLogger().info(s.getName() + ": " + sub + " " + op + " " + t.name + " " + a[3]
                    + (payId != null ? " (payment " + payId + ")" : ""));

            Player online = Bukkit.getPlayer(t.uuid);
            if (online != null && donate && op.equals("give")) {
                online.sendMessage(pl.msg("got-donate", "%amount%", String.valueOf((long) amt)));
                online.playSound(online.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            }
            return;
        }
        s.sendMessage(pl.msg("usage-admin"));
    }

    static double parse(String s) {
        try {
            double d = Double.parseDouble(s.replace(',', '.'));
            if (Double.isNaN(d) || Double.isInfinite(d) || d < 0) return Double.NaN;
            return EcoManager.round(d);
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        String name = c.getName().toLowerCase();
        List<String> out = new ArrayList<>();
        if (name.equals("dualeco") && s.hasPermission("dualeco.admin")) {
            if (a.length == 1) out.addAll(List.of("coins", "donate", "balance", "reload"));
            else if (a.length == 2 && (a[0].equalsIgnoreCase("coins") || a[0].equalsIgnoreCase("donate")))
                out.addAll(List.of("give", "take", "set"));
            else if ((a.length == 3 && !a[0].equalsIgnoreCase("balance")) || (a.length == 2 && a[0].equalsIgnoreCase("balance")))
                Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if ((name.equals("pay") || name.equals("balance")) && a.length == 1) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
