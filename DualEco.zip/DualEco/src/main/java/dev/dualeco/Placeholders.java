package dev.dualeco;

import dev.dualeco.EcoManager.Account;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

/**
 * %dualeco_coins%          — монеты (красиво: 1 250.5)
 * %dualeco_coins_raw%      — монеты (число для requirements в меню)
 * %dualeco_donate%         — донат-валюта (целое число)
 * %dualeco_donate_name%    — название донат-валюты
 */
public class Placeholders extends PlaceholderExpansion {
    private final DualEco pl;
    private final EcoManager m;

    public Placeholders(DualEco pl, EcoManager m) { this.pl = pl; this.m = m; }

    @Override public String getIdentifier() { return "dualeco"; }
    @Override public String getAuthor() { return "DualEco"; }
    @Override public String getVersion() { return "1.0.0"; }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (params.equalsIgnoreCase("donate_name")) return pl.getConfig().getString("donate.name", "Рубины");
        if (player == null) return "";
        Account a = m.get(player.getUniqueId(), player.getName());
        return switch (params.toLowerCase()) {
            case "coins" -> pl.fmtCoins(a.coins);
            case "coins_raw" -> String.valueOf(a.coins);
            case "donate" -> String.valueOf(a.donate);
            default -> null;
        };
    }
}
